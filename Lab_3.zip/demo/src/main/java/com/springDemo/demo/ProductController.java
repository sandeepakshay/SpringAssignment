package com.springDemo.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {
	
	
	         List<Products> list=new ArrayList<Products>();
	         
	        public  ProductController() {
	        	
	        	     list.add(new Products(1,"pen"));
	        	     list.add(new Products(2,"pencil"));
	        	     list.add(new Products(3,"mobile"));
	        }
	        
	        
	        @RequestMapping(value="/products")
	        public ResponseEntity<Object> display(){
	        	
	        	  return new ResponseEntity<>(list,HttpStatus.OK);
	        	       
	        }
	        
	        @RequestMapping(value="/products",method=RequestMethod.POST)
	        public ResponseEntity<Object> add(@RequestBody Products product){
	        	
	        	    list.add(new Products(product.id,product.name));
	        	    return new ResponseEntity<>("Product Added Successfully",HttpStatus.CREATED);
	        }
	        
	        @RequestMapping(value="/products/{id}",method=RequestMethod.DELETE)
	        public ResponseEntity<Object> delete(@PathVariable int id){
	        	
	        	   int index=0;
	        	   for(Products obj:list) {
	        		   
	        		      if(id==obj.id) {
	        		    	  
	        		    	      index=list.indexOf(obj);
	        		      }
	        	   }
	        	 
	        	   list.remove(index);
	        	   return new ResponseEntity<>("Product deleted",HttpStatus.OK);
	        	   
	        }
	        
	        @RequestMapping(value="/products/{id}",method=RequestMethod.PUT)
	        public ResponseEntity<Object> update(@PathVariable int id,@RequestBody Products product){
	        	
	        	int index=0;
	        	for(Products obj:list) {
	        		   
      		      if(id==obj.id) {
      		    	  
      		    	     
      		    	      index=list.indexOf(obj);
      		      }
      	         }
	        	
	        	list.set(index,new Products(id,product.name));
	        	
	        	return new ResponseEntity<>("Updated",HttpStatus.CREATED);
	        	
	        }
	        

}
