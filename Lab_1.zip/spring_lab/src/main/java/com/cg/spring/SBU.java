package com.cg.spring;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

public class SBU {
	
	public int sbuId;
	public String sbuName;
	public String sbuHead;
	
	public List<Employee1> list1;
	
	public List<Employee1> getList1() {
		return list1;
	}
	public void setList1(List<Employee1> list1) {
		this.list1 = list1;
	}
	public int getSbuId() {
		return sbuId;
	}
	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	

}
