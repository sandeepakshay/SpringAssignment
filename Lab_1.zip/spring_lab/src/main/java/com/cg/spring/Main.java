package com.cg.spring;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		
		Scanner sc=new Scanner(System.in);
		
		Employee employee1=(Employee)context.getBean("employee");
		
		System.out.println(employee1.age);
		System.out.println(employee1.eid);
		System.out.println(employee1.salary);
		System.out.println(employee1.employeeName);
		
		System.out.println("****** SBU ******");
		
		System.out.println(employee1.getBussinessUnit().sbuId);
		System.out.println(employee1.getBussinessUnit().sbuName);
		System.out.println(employee1.getBussinessUnit().sbuHead);
		
	    SBU obj2=(SBU)context.getBean("sbu");
	    
	    for(Employee1 emp:obj2.list1) {
	    	
	    	System.out.println(emp.age);
	    	System.out.println(emp.eid);
	    	System.out.println(emp.employeeName);
	    	System.out.println(emp.salary);
	    	
	    }
	   
			  System.out.print("Enter eid:");
			  int s=sc.nextInt();
			  if(s==obj2.getList1().get(0).eid) {
				  
				  
				  for(Employee1 emp:obj2.list1) {
				    	
				    	
				    	System.out.println("Employee id: "+emp.eid);
				    	System.out.println("Employee Name: "+emp.employeeName);
				    	System.out.println("Employee salary :"+emp.salary);
				    	System.out.println("Employee age"+emp.age);
				    	
				    }
				  
				   
			   }
			  else {
				  
				  System.out.println("employee not found");
			  }
		

	}

}
