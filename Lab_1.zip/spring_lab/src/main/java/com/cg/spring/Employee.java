package com.cg.spring;

import java.util.Scanner;

import com.cg.spring.*;

public class Employee {
	
	public int eid;
	public String employeeName;
	public double salary;
	public SBU bussinessUnit;
	public int age;
	SBU s1=new SBU();
	Scanner sc=new Scanner(System.in);
	
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public SBU getBussinessUnit() {
		return bussinessUnit;
	}
	public void setBussinessUnit(SBU bussinessUnit) {
		this.bussinessUnit = bussinessUnit;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	

}
