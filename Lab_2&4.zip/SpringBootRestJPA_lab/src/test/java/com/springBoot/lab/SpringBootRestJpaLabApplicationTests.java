package com.springBoot.lab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestJpaLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
