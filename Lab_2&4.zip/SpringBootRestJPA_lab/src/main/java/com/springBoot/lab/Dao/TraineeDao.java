package com.springBoot.lab.Dao;

import java.util.List;

import com.springBoot.lab.model.Trainee;

public interface TraineeDao {

	public void create(Trainee s);

	public List<Trainee> display();

	public Trainee findById(int id);

	public void delete(int id);

	public void update(Trainee trainee);
}
