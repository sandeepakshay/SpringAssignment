package com.springBoot.lab.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springBoot.lab.Dao.TraineeDao;
import com.springBoot.lab.model.Trainee;

@Transactional
@Service
public class TraineeServiceImp implements TraineeService {

	
	  @Autowired
	  TraineeDao dao;
	
	public void create(Trainee s) {
		
		   dao.create(s);
		
	}

	public List<Trainee> display(){
		
		     return dao.display();
	}

	public Trainee findById(int id) {
		
		  return dao.findById(id);
	}

	public void delete(int id) {
		
		   dao.delete(id);
	}

	public void update(Trainee trainee) {
		
		    dao.update(trainee);
	}
}
