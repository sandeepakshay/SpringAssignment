package com.springBoot.lab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestJpaLabApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestJpaLabApplication.class, args);
	}

}
