package com.springBoot.lab.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class TraineeExceptionController {
	
	private static final long serialVersionUID = 1L;
	
	     @ExceptionHandler(value= {TraineeException.class})
	     public ResponseEntity<Object> handler(TraineeException exception){
	    	 
	    	       return new ResponseEntity<>(exception.getMessage(),HttpStatus.OK);
	     }

}
