package com.springBoot.lab.Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.springBoot.lab.model.Trainee;


@Repository
public class TraineeDaoImp implements TraineeDao {
	
	
	 @PersistenceContext
	 EntityManager em;
	
	public void create(Trainee s) {
		
		     em.persist(s);
	}

	public List<Trainee> display(){
		
		String Qstr="SELECT trainee FROM Trainee trainee";
		TypedQuery<Trainee> query=em.createQuery(Qstr,Trainee.class);
		return query.getResultList();
	}

	public Trainee findById(int id) {
		
		return em.find(Trainee.class, id);
	
	}

	public void delete(int id) {
		
		   Trainee trainee=em.find(Trainee.class, id);
		   em.remove(trainee);
	}

	public void update(Trainee trainee) {
		
		      Trainee updateTrainee=em.find(Trainee.class,trainee.getTraineeId());
		      updateTrainee.setTraineeName(trainee.getTraineeName());
		      updateTrainee.setTraineeDomain(trainee.getTraineeDomain());
		      updateTrainee.setTraineeLocation(trainee.getTraineeLocation());
		      em.persist(updateTrainee);
		
	}

}
