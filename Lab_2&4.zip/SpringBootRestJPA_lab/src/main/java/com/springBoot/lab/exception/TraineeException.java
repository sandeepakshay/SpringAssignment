package com.springBoot.lab.exception;


public class TraineeException extends RuntimeException {

	
	   public TraineeException(String msg) {
		   
		    super(msg);
		    System.out.println("No id found to delete");
	   }
}
