package com.springBoot.lab.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.function.EntityResponse;

import com.springBoot.lab.exception.TraineeException;
import com.springBoot.lab.model.Trainee;
import com.springBoot.lab.services.TraineeService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class TraineeController {
	
	
	       @Autowired
	       TraineeService service;
	       
	        @PostMapping("/add")
	        public ResponseEntity<Object> add(@RequestBody Trainee trainee){
	        	
	        	      service.create(trainee);
	        	      return new ResponseEntity<>("Added successfully",HttpStatus.ACCEPTED);
	        	   
	        }
	        
	        @GetMapping("/display")
	        public ResponseEntity<List<Trainee>> view(){
	        	
	        	List<Trainee> list1=service.display();
	        		
	        	return new ResponseEntity<List<Trainee>>(list1,HttpStatus.OK);
	        	   	
	        }
	        
	        @GetMapping("/view/{id}")
	        public ResponseEntity<Object> viewById(@PathVariable("id") int id){
	        	
	        	     Trainee trainee=service.findById(id);
	        	     if(trainee == null) 
	        	    	throw new TraineeException("No id found");
	        	     return new ResponseEntity<>(trainee,HttpStatus.OK);
	        	
	        	
	        }
	        
	        @DeleteMapping("/delete/{id}")
	        public ResponseEntity<Object> delete(@PathVariable("id") int id) throws TraineeException{
	        	
	        	       service.delete(id);
	        	      
	        	     return new ResponseEntity<>("Deleted your data by id"+id+"successfully",HttpStatus.OK);
	        	
	        	
	        }
	       
	        @PutMapping("/update")
	        public ResponseEntity<Object> update(@RequestBody Trainee trainee){
	        	
	        	  
	        	   service.update(trainee);
	        	   return new ResponseEntity<>("Updated your data",HttpStatus.OK);
	        	
	        }
	       
	       

}
